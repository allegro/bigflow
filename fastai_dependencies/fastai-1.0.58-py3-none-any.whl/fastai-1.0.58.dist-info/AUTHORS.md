# Credits

## Development Lead

- Jeremy Howard

## Core Team

- Sylvain Gugger

## Main Contributors

- Stas Bekman
- Francisco Ingham
- Fred Monroe
- Andrew Shaw
- Rachel Thomas

And a big thanks to all of our GitHub contributors!

